How to publish this landing on GitHub Pages

1) Create a free GitHub account if you don't have one.
2) Create a new repository named "xm-bonus100" (public is fine).
3) Upload the file index.html to the repository root.
4) In the repository settings, go to Pages and select the main branch.
5) Save — GitHub will publish at: https://<your-username>.github.io/xm-bonus100

Or, upload index.html into any hosting (Netlify, Vercel, or your own host).
